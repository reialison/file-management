Dear administrator,<br /> <br />New user has registered on your advanced file management script. Here is information<br /> <br />
Thank you for registering on our <a href="{%linkToScript%}">file management system</a>. Here is your information: <br />
<br />Username: {%username%}
<br />Password: {%password%}
<br />Email: {%email%}
