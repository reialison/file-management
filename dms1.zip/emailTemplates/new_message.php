User {%user%} added message for file {%file%}<br><br>

<h4>Message</h4>
<i><small>{%message%}</small></i>