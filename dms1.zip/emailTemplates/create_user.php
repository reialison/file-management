Hello {%username%},<br /> <br />Please find your login credentials to <a href="{%linkToScript%}">file management system</a><br />
<br />

<br />Username: {%username%}
<br />Password: {%password%}
<br />Email: {%email%}
<br />
<br />
Thank you.