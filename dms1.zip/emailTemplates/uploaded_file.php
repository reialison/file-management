Hello {%name%}<br><br>

New file was uploaded by {%uploader%}!<br>
File: {%file%}