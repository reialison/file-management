File(s) were deleted!,
<br><br>
{%user%} have successfully deleted following files: {%files%}