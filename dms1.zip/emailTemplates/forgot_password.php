Dear {%username%} <br /> <br />
Recently you have reset your password for <a href="{%linkToScript%}">file management system</a>, here it is: <br />
<br />Username: {%username%}
<br />Password: {%password%}
<br />Please change password as soon as you login.