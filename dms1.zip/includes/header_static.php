<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>File Management System</title>
    <link rel='shortcut icon' type='image/x-icon' href='favicon.ico' />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="css/stylesheet.css">
    <link rel="stylesheet" type="text/css" href="css/tipTip.css">
    <link href='//fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.js"></script>
    <script src="//code.jquery.com/ui/1.8.24/jquery-ui.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.8.24/themes/base/jquery-ui.css">
    <script src="js/jquery.tipTip.js"></script>
    <script src="js/main.js"></script>

</head>
<body>
